<?php
include_once('templates/base_top.php');
include_once('templates/base_bottom.php');
header("Location: ${base_url}login.php");
die();
?>